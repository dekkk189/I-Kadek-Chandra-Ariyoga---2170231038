<body style="background-color: #EFF5F5;">

<?php

echo "Page dialihkan"

?>    

</body>