<html lang="in">

    <head>

        <title>Tanggalan</title>

    </head>

    <body style="background-color: #EFF5F5;">

        <?php

        echo date("m F Y, g:i:s a"); ?>

    </body>
    
</html>