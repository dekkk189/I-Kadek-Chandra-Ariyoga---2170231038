<body style="background-color: #EFF5F5;">

<?php

echo "Data kosong";

?>    

</body>